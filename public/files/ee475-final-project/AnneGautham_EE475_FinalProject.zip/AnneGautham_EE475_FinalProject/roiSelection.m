% QPD Spectral Evolution: X, Y, and Rotational Components (Multi-ROI + SNR Ranking)
close all; clear; clc;


folder = 'C:\Users\anneg\Documents\QAO_Work\20251122_HighSpeedCamera';
files = dir(fullfile(folder, '*.avi'));
filename = files(1).name; % analyze first video
filepath = fullfile(folder, filename);
vid = VideoReader(filepath);
Fs = vid.FrameRate;

fprintf('\n=== Processing %s ===\n', filename);
fprintf('Duration = %.1f s | Frame rate = %.1f fps\n', vid.Duration, Fs);

% === STEP 1: Select multiple ROIs ===
numROIs = 3;
roiList = cell(1, numROIs);

vid.CurrentTime = min(vid.Duration * 0.25, vid.Duration - 1);
frame = readFrame(vid);
gray = rgb2gray(frame);

figure(100); imshow(gray, []); title(sprintf('Draw %d ROIs (double-click each)', numROIs));
hold on;
colors = lines(numROIs);
for r = 1:numROIs
    h = drawrectangle('Color', colors(r,:));
    roiList{r} = round(h.Position);
    label = sprintf('ROI %d', r);
    text(roiList{r}(1), roiList{r}(2)-10, label, ...
        'Color', colors(r,:), 'FontSize', 12, 'FontWeight', 'bold');
    pause(0.3);
end
title('ROIs labeled — close window to start analysis');
hold off;
uiwait(gcf); % wait for user to close ROI window
close all;

% === STEP 2: Initialize storage ===
SNRs = zeros(numROIs, 2); % [Qx, Qy]

% === STEP 3: Loop through ROIs ===
for r = 1:numROIs
    roiPos = roiList{r};
    fprintf('\n--- ROI %d/%d ---\n', r, numROIs);
    vid.CurrentTime = 0;

    totalFrames = floor(Fs * vid.Duration);
    Qx = zeros(1, totalFrames);
    Qy = zeros(1, totalFrames);
    t  = (0:totalFrames-1) / Fs;

    for i = 1:totalFrames
        if ~hasFrame(vid), break; end
        frame = readFrame(vid);
        gray  = im2double(rgb2gray(frame));
        crop  = imcrop(gray, roiPos);

        [h, w] = size(crop);
        mx = round(w/2); my = round(h/2);
        A = crop(1:my, 1:mx);
        B = crop(1:my, mx+1:end);
        C = crop(my+1:end, mx+1:end);
        D = crop(my+1:end, 1:mx);

        Qx(i) = (sum(A(:)) + sum(D(:))) - (sum(B(:)) + sum(C(:)));
        Qy(i) = (sum(A(:)) + sum(B(:))) - (sum(C(:)) + sum(D(:)));
    end

    Qx = Qx - mean(Qx);
    Qy = Qy - mean(Qy);
    Qrot = unwrap(atan2(Qy, Qx));

    % === 4. PLOTS ===
    figure('Name', sprintf('ROI %d Components', r), 'Position', [100 100 900 700]);
    subplot(3,1,1); plot(t, Qx, 'b');
    xlabel('Time (s)'); ylabel('Q_x (a.u.)');
    title(sprintf('ROI %d - QPD X Component', r)); grid on;
    subplot(3,1,2); plot(t, Qy, 'r');
    xlabel('Time (s)'); ylabel('Q_y (a.u.)');
    title(sprintf('ROI %d - QPD Y Component', r)); grid on;
    subplot(3,1,3); plot(t, Qrot, 'k');
    xlabel('Time (s)'); ylabel('\theta_{rot} (rad)');
    title(sprintf('ROI %d - QPD Rotational Component', r)); grid on;

    % === 5. SPECTROGRAMS (Qx & Qy only) ===
    window   = hamming(512);
    noverlap = round(0.9 * length(window));
    nfft     = 2048;

    [Sx, Fx, Tx] = spectrogram(Qx, window, noverlap, nfft, Fs);
    figure; imagesc(Tx, Fx, 20*log10(abs(Sx))); axis xy; ylim([0 15]);
    colormap(turbo); colorbar; title(sprintf('Spectrogram Qx (ROI %d)', r));

    [Sy, Fy, Ty] = spectrogram(Qy, window, noverlap, nfft, Fs);
    figure; imagesc(Ty, Fy, 20*log10(abs(Sy))); axis xy; ylim([0 15]);
    colormap(turbo); colorbar; title(sprintf('Spectrogram Qy (ROI %d)', r));

    %snr calculations for Qx and Qy
    L = length(Qx);
    f = (0:L-1) * Fs / L;

    [snrQx, fQx] = simple_snr(Qx, f, Fs);
    [snrQy, fQy] = simple_snr(Qy, f, Fs);

    SNRs(r,:) = [snrQx, snrQy];
    fprintf('ROI %d SNRs:\n   Qx: %.2f dB @ %.2f Hz\n   Qy: %.2f dB @ %.2f Hz\n', ...
        r, snrQx, fQx, snrQy, fQy);

    fprintf('   ROI %d done! Analyzed %.1f s (%.0f frames)\n', r, vid.Duration, totalFrames);
end

% ranking rois
fprintf('\n=== ROI SNR Summary ===\n');
fprintf('ROI |   Qx(dB)   |   Qy(dB)\n');
disp(SNRs);

[~, bestQx] = max(SNRs(:,1));
[~, bestQy] = max(SNRs(:,2));

fprintf('\nBest ROIs:\n');
fprintf('   Qx   → ROI %d\n', bestQx);
fprintf('   Qy   → ROI %d\n', bestQy);

% === 8. Highlight Best ROIs ===
vid.CurrentTime = min(vid.Duration * 0.25, vid.Duration - 1);
frame = readFrame(vid);
gray = rgb2gray(frame);

figure; imshow(gray, []); hold on;
for r = 1:numROIs
    rectangle('Position', roiList{r}, 'EdgeColor', colors(r,:), 'LineWidth', 1.5);
    text(roiList{r}(1), roiList{r}(2)-10, sprintf('ROI %d', r), ...
        'Color', colors(r,:), 'FontSize', 12, 'FontWeight', 'bold');
end
rectangle('Position', roiList{bestQx}, 'EdgeColor', 'cyan', 'LineWidth', 3);
rectangle('Position', roiList{bestQy}, 'EdgeColor', 'magenta', 'LineWidth', 3);
title('ROI Map (Cyan = Best Qx, Magenta = Best Qy)');
hold off;

%choose roi
chosenROI = input('\nEnter ROI number to SAVE: ');
if isempty(chosenROI) || chosenROI < 1 || chosenROI > numROIs
    error('Invalid ROI selection.');
end

% recomp for chosen roi
fprintf('\n--- Exporting ROI %d ---\n', chosenROI);
roiPos = roiList{chosenROI};
vid.CurrentTime = 0;
totalFrames = floor(Fs * vid.Duration);
Qx = zeros(1, totalFrames);
Qy = zeros(1, totalFrames);
t  = (0:totalFrames-1) / Fs;

for i = 1:totalFrames
    if ~hasFrame(vid), break; end
    frame = readFrame(vid);
    gray  = im2double(rgb2gray(frame));
    crop  = imcrop(gray, roiPos);

    [h, w] = size(crop);
    mx = round(w/2); my = round(h/2);
    A = crop(1:my, 1:mx);
    B = crop(1:my, mx+1:end);
    C = crop(my+1:end, mx+1:end);
    D = crop(my+1:end, 1:mx);

    Qx(i) = (sum(A(:)) + sum(D(:))) - (sum(B(:)) + sum(C(:)));
    Qy(i) = (sum(A(:)) + sum(B(:))) - (sum(C(:)) + sum(D(:)));
end

Qx = Qx - mean(Qx);
Qy = Qy - mean(Qy);
Qrot = unwrap(atan2(Qy, Qx));

% save
outdir = fullfile(folder, 'Results', sprintf('ROI_%d', chosenROI));
if ~exist(outdir, 'dir')
    mkdir(outdir);
end

save(fullfile(outdir, 'QPD_data.mat'), 't', 'Qx', 'Qy', 'Qrot', 'roiPos', 'chosenROI', 'filename', 'Fs');

% Plot and save figures
figure; plot(t, Qx, 'b'); hold on; plot(t, Qy, 'r');
xlabel('Time (s)'); ylabel('QPD signal (a.u.)');
legend('Qx','Qy'); title(sprintf('QPD Signals (ROI %d)', chosenROI)); grid on;
saveas(gcf, fullfile(outdir, 'QPD_XY_TimeSeries.png'));

figure; plot(t, Qrot, 'k');
xlabel('Time (s)'); ylabel('\theta_{rot} (rad)');
title(sprintf('QPD Rotational Signal (ROI %d)', chosenROI)); grid on;
saveas(gcf, fullfile(outdir, 'QPD_Rot_TimeSeries.png'));

% Spectrograms for Qx, Qy only
window = hamming(512);
noverlap = round(0.9 * length(window));
nfft = 2048;
[Sx, Fx, Tx] = spectrogram(Qx, window, noverlap, nfft, Fs);
[Sy, Fy, Ty] = spectrogram(Qy, window, noverlap, nfft, Fs);

figure; imagesc(Tx, Fx, 20*log10(abs(Sx))); axis xy; ylim([0 15]);
colormap(turbo); colorbar;
title(sprintf('Spectrogram Qx (ROI %d)', chosenROI));
xlabel('Time (s)'); ylabel('Frequency (Hz)');
saveas(gcf, fullfile(outdir, 'Spectrogram_Qx.png'));

figure; imagesc(Ty, Fy, 20*log10(abs(Sy))); axis xy; ylim([0 15]);
colormap(turbo); colorbar;
title(sprintf('Spectrogram Qy (ROI %d)', chosenROI));
xlabel('Time (s)'); ylabel('Frequency (Hz)');
saveas(gcf, fullfile(outdir, 'Spectrogram_Qy.png'));

fprintf('\nSaved ROI %d data and figures to:\n   %s\n', chosenROI, outdir);


% helper snr function
function [snr_dB, fpeak] = simple_snr(sig, f, Fs)
    % Parameters
    target_band = [4 6];        % expected physical band (Hz)
    noise_exclude = [4 7];      %noise band
    df = f(2)-f(1);

    % FFT
    X = abs(fft(sig .* hamming(length(sig))'));
    X = X(1:floor(end/2)); f2 = f(1:floor(end/2));

    %band power
    sig_band = (f2 >= target_band(1) & f2 <= target_band(2));
    [~, idx_peak] = max(X(sig_band));
    fpeak = f2(find(sig_band,1) + idx_peak - 1);
    Psig = mean(X(sig_band).^2);
    noise_band  = (f2 > 0.5 & f2 < Fs/2) & ...
                 ~(f2 >= noise_exclude(1) & f2 <= noise_exclude(2));
    Pnoise = mean(X(noise_band).^2);

    % --- Final SNR ---
    snr_dB = 10*log10(Psig / Pnoise);
end
