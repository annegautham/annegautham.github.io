% =========================================================================
% QPD stitched spectrogram + mode tracking + adaptive Hilbert freq / phase
% estimation
close all; clear; clc;

% settings
analysisChannel = 'Qy';   % 'Qx' or 'Qy'
baseFolder      = 'C:\Users\anneg\Documents\QAO_Work\WeakProbe\Results';
gap_sec         = 1000;   % known delay between videos
nModes          = 3;
expected_dur    = 120;    % seconds per video, for display only

% stitching spectrograms together
fprintf('=== STITCHING ALL SEGMENTS (%s) ===\n', analysisChannel);
subdirs = dir(fullfile(baseFolder, 'record*'));
subdirs = subdirs([subdirs.isdir]);

S_all = [];           % stitched spectrogram
T_all = [];           % stitched time for spectrogram
F_ref = [];           % reference frequency axis

Q_all      = [];      % stitched time-domain signal
valid_mask = [];      % marks real vs gap samples
Fs_list    = [];

time_offset   = 0;
segment_start = [];
seg_col_start = [];   % <-- column start index in S_all/T_all per segment
seg_col_end   = [];   % <-- column end index per segment

for k = 1:numel(subdirs)
    basePath = fullfile(baseFolder, subdirs(k).name);
    f1 = fullfile(basePath, 'SpectroData.mat');
    f2 = fullfile(basePath, 'ROI_3', 'SpectroData.mat');

    if isfile(f1)
        f = f1;
    elseif isfile(f2)
        f = f2;
    else
        fprintf('Skipping %s (no SpectroData.mat)\n', subdirs(k).name);
        continue;
    end

    d = load(f, 'Sx','Fx','Tx','Sy','Fy','Ty','Qx','Qy','Fs');

    % pick channel
    switch analysisChannel
        case 'Qx'
            S = d.Sx; F = d.Fx; T = d.Tx; Q = d.Qx;
        case 'Qy'
            S = d.Sy; F = d.Fy; T = d.Ty; Q = d.Qy;
    end

    if isempty(F_ref)
        F_ref = F;
    end

    Fs = d.Fs;
    Fs_list(end+1) = Fs; %#ok<SAGROW>

    % rescale spectrogram time to 0..expected_dur for this segment
    T_rescaled = linspace(0, expected_dur, numel(T));
    T_shift    = T_rescaled + time_offset;

    % column bookkeeping before appending
    col_start_this = size(T_all,2) + 1;
    col_end_this   = col_start_this + numel(T_shift) - 1;
    seg_col_start(end+1) = col_start_this; %#ok<SAGROW>
    seg_col_end(end+1)   = col_end_this;   %#ok<SAGROW>

    % append spectrogram data
    S_all = [S_all, S];
    T_all = [T_all, T_shift];

    % stitch real Q with explicit gaps
    if isempty(Q_all)
        Q_all      = Q(:);
        valid_mask = true(numel(Q),1);
    else
        gap_samp   = round(gap_sec * Fs);
        Q_all      = [Q_all; zeros(gap_samp,1); Q(:)];
        valid_mask = [valid_mask; false(gap_samp,1); true(numel(Q),1)];
    end

    segment_start(end+1) = time_offset; %#ok<SAGROW>

    fprintf('Loaded %-28s | start %6.0fs | shown dur %6.0fs | actual spectro %.1fs\n', ...
        subdirs(k).name, time_offset, expected_dur, T(end));

    time_offset = time_offset + expected_dur + gap_sec;
end

Fs    = mode(Fs_list);
t_sig = (0:numel(Q_all)-1)/Fs;
fprintf('Total time %.1fs, samples %d\n', t_sig(end), numel(t_sig));

% show stitched spectrogram
figure('Name',sprintf('Stitched Spectrogram – %s',analysisChannel),...
    'Position',[100 100 1400 650]);
imagesc(T_all, F_ref, 20*log10(abs(S_all)));
axis xy; ylim([0 15]); colormap turbo; colorbar;
xlabel('Time (s)'); ylabel('Frequency (Hz)');
title(sprintf('Stitched Spectrogram – %s',analysisChannel));
hold on;
for i = 1:numel(segment_start)
    xline(segment_start(i), 'k--', 'LineWidth', 0.75, 'HandleVisibility','off');
end
hold off;

% ------------------------------------------------------------------------
% 3) MODE TRACKING (freq + robust amplitude)
% ------------------------------------------------------------------------
fprintf('\n=== Tracking dominant modes ===\n');
Smag  = abs(S_all);
freqs = F_ref(:);
[~, nTime] = size(Smag);

freq_modes = nan(nModes, nTime);
amp_modes  = nan(nModes, nTime);

% tracking params
bw_int      = 0.75;
w_freq      = 1.0;
w_amp       = 0.3;
max_jump_Hz = 1.0;

% init from first column
[pks0, locs0] = findpeaks(Smag(:,1), freqs, 'SortStr','descend');
n0 = min(nModes, numel(pks0));
freq_modes(1:n0,1) = locs0(1:n0);
for m = 1:n0
    fc   = locs0(m);
    mask = (freqs >= fc - bw_int) & (freqs <= fc + bw_int);
    if ~any(mask)
        [~,idxn] = min(abs(freqs - fc));
        mask(idxn) = true;
    end
    amp_modes(m,1) = sqrt(sum(Smag(mask,1).^2));
end

% forward tracking
for tIdx = 2:nTime
    col = Smag(:,tIdx);
    [pks, locs] = findpeaks(col, freqs, 'SortStr','descend');

    if isempty(pks)
        freq_modes(:,tIdx) = freq_modes(:,tIdx-1);
        amp_modes(:,tIdx)  = amp_modes(:,tIdx-1);
        continue;
    end

    for m = 1:nModes
        f_prev = freq_modes(m, tIdx-1);
        if isnan(f_prev)
            [~, idx_reinit] = max(pks);
            freq_modes(m, tIdx) = locs(idx_reinit);
            amp_modes(m, tIdx)  = pks(idx_reinit);
            continue;
        end

        freq_diff = abs(locs - f_prev);
        cost = w_freq*freq_diff - w_amp*(pks / max(pks));
        cost(freq_diff > max_jump_Hz) = Inf;

        [minCost, idx_min] = min(cost);
        if isfinite(minCost)
            fc = locs(idx_min);
            freq_modes(m, tIdx) = fc;

            mask = (freqs >= fc - bw_int) & (freqs <= fc + bw_int);
            if ~any(mask)
                [~, idxn] = min(abs(freqs - fc));
                mask(idxn) = true;
            end
            amp_now = sqrt(sum(col(mask).^2));
            amp_modes(m, tIdx) = 0.8*amp_modes(m, tIdx-1) + 0.2*amp_now;
        else
            freq_modes(m, tIdx) = freq_modes(m, tIdx-1);
            amp_modes(m, tIdx)  = amp_modes(m, tIdx-1);
        end
    end
end

% smoothing
for m = 1:nModes
    freq_modes(m,:) = smoothdata(freq_modes(m,:), 'movmedian', 25);
    % amp_modes(m,:)  = smoothdata(amp_modes(m,:),  'gaussian', 15);
end

% ------------------------------------------------------------------------
% build dense time + dense amplitude for plotting
points_per_seg = 200;  % how many points to show per video on the plot
nSeg = numel(segment_start);

T_dense_all   = [];
amp_dense_all = nan(nModes, nSeg*points_per_seg);

for s = 1:nSeg
    cs = seg_col_start(s);
    ce = seg_col_end(s);

    T_seg = T_all(cs:ce);                  % stitched time for this segment
    T_seg_dense = linspace(T_seg(1), T_seg(end), points_per_seg);

    T_dense_all = [T_dense_all, T_seg_dense];

    for m = 1:nModes
        a_seg = amp_modes(m, cs:ce);
        % pchip to avoid flat parts
        a_seg_dense = interp1(T_seg, a_seg, T_seg_dense, 'pchip');
        amp_dense_all(m, (s-1)*points_per_seg + (1:points_per_seg)) = a_seg_dense;
    end
end

amp_total_dense = sum(amp_dense_all, 1, 'omitnan');


% plot tracked modes with dense time
figure('Name',sprintf('Dominant modes from spectrogram (%s)',analysisChannel),...
    'Position',[100 100 1300 550]);
colors = lines(nModes);
hold on; grid on; box on;

for m = 1:nModes
    plot(T_dense_all, amp_dense_all(m,:), 'Color', colors(m,:), 'LineWidth', 1.3, ...
        'DisplayName', sprintf('Mode %d (%.2f Hz)', m, ...
        median(freq_modes(m,~isnan(freq_modes(m,:)))) ));
end

plot(T_dense_all, amp_total_dense, 'k', 'LineWidth', 2, 'DisplayName','Total amplitude');

for i = 1:numel(segment_start)
    xline(segment_start(i), 'k--', 'HandleVisibility','off');
end
xlabel('Time (s)');
ylabel('Amplitude (a.u.)');
title(sprintf('Dominant modes from spectrogram (%s)', analysisChannel));
legend('show');


%adaptive sliding hilbert
fprintf('\n=== Sliding adaptive Hilbert tracking ===\n');

Q_all = detrend(Q_all(:));
Nsig  = numel(Q_all);

win_sec  = 10;
hop_sec  = 5;
win_samp = round(win_sec * Fs);
hop_samp = round(hop_sec * Fs);
nWindows = floor((Nsig - win_samp)/hop_samp) + 1;

A_slide   = nan(nModes, Nsig);
phi_slide = nan(nModes, Nsig);
bw_hilb   = 0.4;

for w = 1:nWindows
    s = (w-1)*hop_samp + 1;
    e = s + win_samp - 1;
    idx = s:e;

    t_mid = mean(t_sig(idx));
    [~, spec_idx] = min(abs(T_all - t_mid));

    for m = 1:nModes
        fc = freq_modes(m, spec_idx);
        if isnan(fc) || fc == 0
            continue;
        end

        f1 = max(0.1, fc - bw_hilb);
        f2 = min(fc + bw_hilb, 0.98*(Fs/2));
        if f1 >= f2
            continue;
        end

        [b,a] = butter(4, [f1 f2]/(Fs/2), 'bandpass');
        seg   = Q_all(idx);
        seg_f = filtfilt(b,a,seg);
        z     = hilbert(seg_f);
        A_loc = abs(z);
        phi_loc = unwrap(angle(z));

        A_prev   = A_slide(m, idx);
        phi_prev = phi_slide(m, idx);
        mask_prev = ~isnan(A_prev);

        A_prev(mask_prev)   = 0.5*(A_prev(mask_prev) + A_loc(mask_prev).');
        phi_prev(mask_prev) = 0.5*(phi_prev(mask_prev) + phi_loc(mask_prev).');

        A_prev(~mask_prev)   = A_loc(~mask_prev).';
        phi_prev(~mask_prev) = phi_loc(~mask_prev).';

        A_slide(m, idx)   = A_prev;
        phi_slide(m, idx) = phi_prev;
    end
end

% inst. freq
f_inst_slide = nan(size(A_slide));
for m = 1:nModes
    ph = phi_slide(m,:);
    if all(isnan(ph)), continue; end
    dph = [diff(ph), NaN];
    f_inst_slide(m,:) = Fs/(2*pi) * dph;
    f_inst_slide(m, f_inst_slide(m,:) < 0) = NaN;
end

% relative phases
pair_idx = nchoosek(1:nModes, 2);
phi_rel_all = nan(size(pair_idx,1), Nsig);
for p = 1:size(pair_idx,1)
    m1 = pair_idx(p,1); m2 = pair_idx(p,2);
    mask = ~isnan(phi_slide(m1,:)) & ~isnan(phi_slide(m2,:));
    tmp  = unwrap(phi_slide(m1,mask) - phi_slide(m2,mask));
    phi_rel_all(p,mask) = tmp;
end

% kill gap parts
A_slide(:, ~valid_mask)      = NaN;
f_inst_slide(:, ~valid_mask) = NaN;
phi_rel_all(:, ~valid_mask)  = NaN;

% plotting
t_comp = cumsum(valid_mask)/Fs;
t_comp(~valid_mask) = NaN;
scale_factor  = t_sig(end) / max(t_comp(~isnan(t_comp)));
t_comp_scaled = t_comp * scale_factor;

xline_positions = nan(size(segment_start));
for i = 1:numel(segment_start)
    % --- find closest matching sample index for the segment start ---
    idx_candidates = find(t_sig >= segment_start(i));

    if isempty(idx_candidates)
        % no usable index found — just skip this xline
        xline_positions(i) = NaN;
        continue;
    end

    % pick the first index
    idx = idx_candidates(1);

    % ensure idx is a scalar
    idx = idx(1);

    % iterate forward until hitting a valid sample
    while idx <= numel(valid_mask) && ~logical(valid_mask(idx))
        idx = idx + 1;
    end

    % record xline if inside range
    if idx <= numel(t_comp_scaled)
        xline_positions(i) = t_comp_scaled(idx);
    else
        xline_positions(i) = NaN;
    end

end

% amplitude (gapless)
figure('Name',sprintf('Adaptive amplitudes (gapless, %s)',analysisChannel),...
    'Position',[100 100 1300 400]);
hold on; grid on; box on;
for m = 1:nModes
    plot(t_comp_scaled, A_slide(m,:), 'Color', colors(m,:), 'LineWidth', 1.1, ...
        'DisplayName', sprintf('Mode %d (adaptive)', m));
end
for i = 1:numel(xline_positions)
    xline(xline_positions(i), 'k--', 'HandleVisibility','off');
end
xlabel('Time (s)'); ylabel('Amplitude (a.u.)');
title(sprintf('Sliding/adaptive amplitude envelopes (gapless view, %s)',analysisChannel));
legend('show');

% frequency (gapless)
figure('Name',sprintf('Adaptive frequency (gapless, %s)',analysisChannel),...
    'Position',[100 550 1300 400]);
hold on; grid on; box on;
for m = 1:nModes
    plot(t_comp_scaled, f_inst_slide(m,:), 'Color', colors(m,:), 'LineWidth', 1.1);
    plot(t_comp_scaled, smoothdata(f_inst_slide(m,:), 'gaussian', 15));
end
for i = 1:numel(xline_positions)
    xline(xline_positions(i), 'k--', 'HandleVisibility','off');
end
xlabel('Time (s)'); ylabel('Frequency (Hz)');
title(sprintf('Sliding/adaptive instantaneous frequency (gapless view, %s)',analysisChannel));
ylim([0 15]);

% relative phase (gapless)
figure('Name',sprintf('Adaptive relative phases (gapless, %s)',analysisChannel),...
    'Position',[100 1000 1300 350]);
hold on; grid on; box on;
pair_labels = {};
for p = 1:size(pair_idx,1)
    plot(t_comp_scaled, unwrap(mod(phi_rel_all(p,:), 2*pi)), 'LineWidth', 1.0);
    pair_labels{p} = sprintf('Mode %d–Mode %d', pair_idx(p,1), pair_idx(p,2));
end
for i = 1:numel(xline_positions)
    xline(xline_positions(i), 'k--', 'HandleVisibility','off');
end
xlabel('Time (s)'); ylabel('Phase diff (rad)');
title(sprintf('Relative phase differences (gapless view, %s)',analysisChannel));
legend(pair_labels, 'Location', 'best');



figure;
hold on;

plot(freq_modes(1, :));
plot(freq_modes(2, :));
plot(freq_modes(3, :));