%% =========================================================================
%  QPD Spectral Evolution — Fixed Duration Using Actual Video Frame Rate
% ==========================================================================
close all; clear; clc;

% === PATHS ===
baseFolder = 'C:\Users\anneg\Documents\QAO_Work\20251122_HighSpeedCamera';
roiFile    = fullfile(baseFolder, 'Results', 'ROI_1', 'QPD_data.mat');

if ~isfile(roiFile)
    error('ROI file not found:\n%s', roiFile);
end

% loading roi data
roiData = load(roiFile, 'roiPos', 'Fs');
roiPos  = roiData.roiPos;
Fs_ROI  = roiData.Fs;

fprintf('Loaded ROI from %s\n', roiFile);
fprintf('ROI = [%.0f %.0f %.0f %.0f], nominal Fs_ROI = %.1f Hz\n', roiPos, Fs_ROI);

%loading videos
files = dir(fullfile(baseFolder, '*.avi'));
fprintf('Found %d video(s).\n', numel(files));

% stft params
window   = hamming(512);
noverlap = round(0.9 * numel(window));
nfft     = 2048;

% Launch parallel pool if not active
if isempty(gcp('nocreate'))
    parpool('threads');
end

% para loop
parfor k = 1:numel(files)
    filename = files(k).name;
    filepath = fullfile(baseFolder, filename);

    outdir  = fullfile(baseFolder, 'Results', erase(filename, '.mp4'));
    outfile = fullfile(outdir, 'SpectroData.mat');

    if isfile(outfile)
        fprintf('Skipping %-25s (already processed)\n', filename);
        continue;
    end
    if ~exist(outdir, 'dir')
        mkdir(outdir);
    end

    fprintf('\n--- Processing %-25s ---\n', filename);
    vid = VideoReader(filepath);

    % === Use actual video frame rate ===
    Fs_video = vid.FrameRate;
    totalFrames = floor(Fs_video * vid.Duration);
    fprintf('Frame rate: %.2f Hz, Duration: %.1fs, Total frames: %d\n', ...
        Fs_video, vid.Duration, totalFrames);

    % preallocate
    Qx = zeros(1, totalFrames);
    Qy = zeros(1, totalFrames);
    t  = (0:totalFrames-1) / Fs_video;

    % process frames
    frameCount = 0;
    for i = 1:totalFrames
        if ~hasFrame(vid)
            break;
        end
        frame = readFrame(vid);
        gray  = im2double(rgb2gray(frame));
        crop  = imcrop(gray, roiPos);
        
        [h, w] = size(crop);
        mx = round(w/2); my = round(h/2);
        A = crop(1:my, 1:mx);
        B = crop(1:my, mx+1:end);
        C = crop(my+1:end, mx+1:end);
        D = crop(my+1:end, 1:mx);
    
        frameCount = frameCount + 1;
        Qx(frameCount) = (sum(A(:)) + sum(D(:))) - (sum(B(:)) + sum(C(:)));
        Qy(frameCount) = (sum(A(:)) + sum(B(:))) - (sum(C(:)) + sum(D(:)));
    end
    
    % trim actual frames
    Qx = Qx(1:frameCount);
    Qy = Qy(1:frameCount);
    t  = (0:frameCount-1) / Fs_video;
    
    % remove dc offsets
    Qx = Qx - mean(Qx);
    Qy = Qy - mean(Qy);
    Qrot = unwrap(atan2(Qy, Qx));
    
    % spectrograms
    [Sx, Fx, Tx] = spectrogram(Qx, window, noverlap, nfft, Fs_video);
    [Sy, Fy, Ty] = spectrogram(Qy, window, noverlap, nfft, Fs_video);

    Tx = Tx * ((numel(Qx)-1)/Fs_video) / Tx(end);
    Ty = Ty * ((numel(Qy)-1)/Fs_video) / Ty(end);

    % svaing results over all videos
    S = struct( ...
        'Sx', Sx, 'Fx', Fx, 'Tx', Tx, ...
        'Sy', Sy, 'Fy', Fy, 'Ty', Ty, ...
        'Qx', Qx, 'Qy', Qy, 'Qrot', Qrot, ...
        'Fs', Fs_video, 'roiPos', roiPos, ...
        'duration', vid.Duration, 'frameCount', numel(Qx));

    outfile = fullfile(outdir, 'SpectroData.mat');
    save(outfile, '-fromstruct', S);  % parfor-safe
    fprintf('Saved %s\n', outfile);
end

fprintf('All videos processed successfully (full durations retained).\n');
